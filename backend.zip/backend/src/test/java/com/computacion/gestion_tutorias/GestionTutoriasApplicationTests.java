package com.computacion.gestion_tutorias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionTutoriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
