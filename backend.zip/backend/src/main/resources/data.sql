INSERT INTO
    rol (id, descripcion, nombre)
VALUES
    (
        1,
        'Descripción del rol de estudiante',
        'estudiante'
    ),
    (2, 'Descripción del rol de docente', 'docente'),
    (3, 'Descripción del rol de admin', 'admin'),
    (4, 'Descripción del rol de gestor', 'gestor');

INSERT INTO
    asignatura(id,)